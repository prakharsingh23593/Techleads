package com.quest.library;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.quest.library.BookEntity.BookEntity;
import com.quest.library.BookRepository.BookRepository;

@SpringBootTest
class BookLibraryApplicationTests {
	@Autowired
	BookRepository bookRepository;
//Set the value
	@Test
	public void testCreate() {
		BookEntity book = new BookEntity();
		book.setBookid(1L);
		book.setBooksubject("java");
		book.setBookAuthor("prakhar");
		bookRepository.save(book);
		assertNotNull(bookRepository.findById(1L).get());
	}
//find the grater value
	@Test
	public void testReadAll() {
		List<BookEntity> list = bookRepository.findAll();
		assertThat(list).size().isGreaterThan(0);
	}
//campare the two string
	@Test
	public void testSingleBook() {
		BookEntity BookEntity = bookRepository.findById(1L).get();
		assertEquals(1L, BookEntity.getBookid());
	}
	//update previous value 
	@Test
	public void testUpdate() {
		BookEntity Repo=bookRepository.findById(1L).get();
		Repo.setBookAuthor("Rajat");
		Repo.setBookid(4L);
	    Repo.setBooksubject("C++"); 
	    assertNotEquals("Prakhar",bookRepository.findById(1L).get().getBookauthor());
		//delete the value
	}
	@Test
	public void testDelete() {
		bookRepository.deleteById(1L);
		assertThat(bookRepository.existsById(1L)).isFalse();
		
	}
	
}

