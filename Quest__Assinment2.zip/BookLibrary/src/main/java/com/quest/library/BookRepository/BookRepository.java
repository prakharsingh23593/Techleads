package com.quest.library.BookRepository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.quest.library.BookEntity.BookEntity;
public interface BookRepository extends JpaRepository<BookEntity,Long> {

	

}
