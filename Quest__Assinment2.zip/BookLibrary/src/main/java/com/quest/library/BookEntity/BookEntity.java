package com.quest.library.BookEntity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Book")
public class BookEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long bookid;

	private String booksubject;

	private String bookauthor;

	public BookEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BookEntity(Long bookid, String booksubject, String bookAuthor) {
		super();
		this.bookid = bookid;
		this.booksubject = booksubject;
		this.bookauthor = bookAuthor;
	}

	public Long getBookid() {
		return bookid;
	}

	public void setBookid(Long bookid) {
		this.bookid = bookid;
	}

	public String getBooksubject() {
		return booksubject;
	}

	public void setBooksubject(String booksubject) {
		this.booksubject = booksubject;
	}

	public String getBookauthor() {
		return bookauthor;
	}

	public void setBookAuthor(String bookauthor) {
		this.bookauthor = bookauthor;
	}

}
