package com.quest.library.BookService;

import java.util.List;

import javax.management.relation.RoleNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.quest.library.BookEntity.BookEntity;
import com.quest.library.BookRepository.BookRepository;

@Service
public  class BookServiceImpl implements BookService{
	private BookRepository bookRepository;
	public BookServiceImpl(BookRepository bookRepository) {
		super();
		this.bookRepository = bookRepository;
	}

	

	@Override
	public List<BookEntity> getAllBooks() {
		// TODO Auto-generated method stub
		return bookRepository.findAll();
	}

	@Override
	public BookEntity addBook(BookEntity BookEntity) {
		// TODO Auto-generated method stub
		return bookRepository.save(BookEntity);
	}

	@Override
	public BookEntity getBookById(long bookid) {
		// TODO Auto-generated method stub
		return bookRepository.getById(bookid);
	}
	
	
	}


