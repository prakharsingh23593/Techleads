package com.quest.library.BookService;

import java.util.List;

import com.quest.library.BookEntity.BookEntity;

public interface BookService {
	
	//Some abstract method
	List<BookEntity> getAllBooks();
	BookEntity addBook(BookEntity BookEntity);
	BookEntity getBookById(long bookid);
   
}
