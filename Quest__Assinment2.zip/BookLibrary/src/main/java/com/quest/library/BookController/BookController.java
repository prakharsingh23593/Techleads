package com.quest.library.BookController;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.quest.library.BookEntity.BookEntity;
import com.quest.library.BookRepository.BookRepository;
import com.quest.library.BookService.BookService;

@RestController

public class BookController {
	private BookService bookService;
	public BookController(BookService bookService) {
		super();
		this.bookService = bookService;
	}

   
  @PostMapping("/addbook")
  public ResponseEntity<BookEntity>addbook(@RequestBody BookEntity book){
	  return new ResponseEntity<BookEntity>(bookService.addBook(book),HttpStatus.CREATED);

		
	}
  @GetMapping("/getAllbooks")
  public List<BookEntity> getAllBooks(){
	  return bookService.getAllBooks();
  }
  @GetMapping("{id}")
  public ResponseEntity<BookEntity> getBookById(@PathVariable("id")long bookId){
	  return new ResponseEntity<BookEntity>(bookService.getBookById(bookId),HttpStatus.OK);
  } 
}


