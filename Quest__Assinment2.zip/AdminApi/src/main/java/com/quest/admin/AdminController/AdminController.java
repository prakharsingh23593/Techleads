package com.quest.admin.AdminController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.quest.admin.Entity.BookEntity;

@RestController
@RequestMapping("/admin")
public class AdminController {
	
	@Autowired
	private RestTemplate restTemplate;
	
	@GetMapping("/getAllBookByAdmin")
	public List<BookEntity>getAllBooks(){
		List<BookEntity>book=restTemplate.getForObject("http://localhost:8010//getAllbooks",List.class);
		return book;
	}

}
