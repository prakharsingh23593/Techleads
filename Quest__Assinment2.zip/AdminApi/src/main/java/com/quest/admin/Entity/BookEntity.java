package com.quest.admin.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class BookEntity {
	
	@Id
	private Long BookNo;
	
	@Column(name="BookName")
	private String BookName;
	
	@Column(name="Subject")
	private String Subject;
	
	
	public BookEntity() {
		super();
		// TODO Auto-generated constructor stub
	}


	public BookEntity(Long bookNo, String bookName, String subject) {
		super();
		BookNo = bookNo;
		BookName = bookName;
		Subject = subject;
	}


	public Long getBookNo() {
		return BookNo;
	}


	public void setBookNo(Long bookNo) {
		BookNo = bookNo;
	}


	public String getBookName() {
		return BookName;
	}


	public void setBookName(String bookName) {
		BookName = bookName;
	}


	public String getSubject() {
		return Subject;
	}


	public void setSubject(String subject) {
		Subject = subject;
	}
	

	
}
