package com.quest.library.StudentService;

import java.util.List;

import org.springframework.stereotype.Service;

import com.quest.library.StudentEntity.Student;
import com.quest.library.StudentRepository.StudentRepository;
@Service
public class StudentServiceImpl implements StudentService {

	private StudentRepository studentRepository;

	public StudentServiceImpl(StudentRepository studentRepository) {
		super();
		this.studentRepository = studentRepository;
	}

	@Override
	public List<Student>getAllStudents(){
		// TODO Auto-generated method stub
		return studentRepository.findAll();
	}

}
