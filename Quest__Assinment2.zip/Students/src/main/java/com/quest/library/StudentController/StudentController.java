package com.quest.library.StudentController;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.quest.library.StudentEntity.Student;
import com.quest.library.StudentService.StudentService;
//StudentController class
@RestController
public class StudentController {
	private StudentService studentService;

	public StudentController(StudentService studentservice) {
		super();
		this.studentService = studentservice;
	}
	
	//get All Student Details
	  @GetMapping("/getAllStudents")
	  public List<Student> getAllStudents(){
		  return studentService.getAllStudents();

}
}