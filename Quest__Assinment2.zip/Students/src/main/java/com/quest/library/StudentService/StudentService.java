package com.quest.library.StudentService;

import java.util.List;

import com.quest.library.StudentEntity.Student;

public interface StudentService {
  List<Student> getAllStudents();
   

 
}
