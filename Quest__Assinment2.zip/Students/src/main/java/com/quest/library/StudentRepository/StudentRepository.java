package com.quest.library.StudentRepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.quest.library.StudentEntity.Student;

public interface StudentRepository extends JpaRepository<Student,Long> {

}
