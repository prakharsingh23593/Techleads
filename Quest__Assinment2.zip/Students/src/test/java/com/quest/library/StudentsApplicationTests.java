package com.quest.library;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.quest.library.StudentEntity.Student;
import com.quest.library.StudentRepository.StudentRepository;

@SpringBootTest
class StudentsApplicationTests {
	@Autowired
	StudentRepository studentRepository;

	@Test
	public void testCreate() {
		Student s = new Student();
		s.setId(1l);
		s.setName("prakhar");
		s.setCourse("MCA");
		studentRepository.save(s);
		assertNotNull(studentRepository.findById(1L).get());

	}

	@Test
	public void testReadAll() {
		List<Student> list = studentRepository.findAll();
		assertThat(list).size().isGreaterThan(0);
	}

	@Test
	public void testSingleBook() {
		Student student = studentRepository.findById(1L).get();
		assertEquals(1L, student.getId());
	}

	@Test
	public void testUpdate() {
		Student std = studentRepository.findById(1L).get();
		std.setName("Rajat");
		std.setId(2l);
		std.setCourse("BCA");

		assertNotEquals("Prakhar", studentRepository.findById(1L).get().getName());

	}
}
